#!/bin/sh
#
# home directory in variable
ACTDIR=`pwd`
echo "0,10,20,30,40,50 * * * * $ACTDIR/system_check.sh SYS 1> $ACTDIR/system_check.log 2> $ACTDIR/system_check.err

"|crontab
if [ "$?" != "0" ]
then
	echo "First attempt add crontab failed"
	echo "0,10,20,30,40,50 * * * * $ACTDIR/system_check.sh SYS 1> $ACTDIR/system_check.log 2> $ACTDIR/system_check.err
	
"|crontab -
	
fi
if [ "$?" != "0" ]
then
	echo "RDAT_ABORT Unable to add crontab."
else
	echo "Crontab added."
fi