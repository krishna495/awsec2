#!/bin/sh
tar xvf /usr/local/atstbx/linux/toolbx.tar
if [ "$?" != "0" ]
then
	echo "ERROR Unable to unpack archive"
fi
