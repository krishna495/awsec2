#!/bin/sh
ACTDIR=`pwd`
chmod 0755 .
#chmod 0755 R3D3_agent
#chmod 0755 system_check.sh
#chmod 0755 bin
#chmod 0750 log
#chmod 0700 .ssh
#chmod 0600 .ssh/authorized_keys
chown -R atstbx:atstbx .
